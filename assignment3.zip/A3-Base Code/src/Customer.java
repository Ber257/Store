import java.io.Serializable;
import java.util.ArrayList;
import java.util.*;

public class Customer implements Comparable<Customer>, Serializable {
    private String name;
    private double moneySpent;//keeps track of the amount of money spent
    private HashMap<Product,Integer> purchaseHistory;
    private List<Customer> names = new ArrayList<>();

    //Customer constructor
    public Customer(String s) {
        this.name = s;
        this.moneySpent = 0.0F;
        this.purchaseHistory = new HashMap<Product, Integer>();
        names.add(this);
    }

    public void purchaseMade(Product p, int amount){
        //If the purchase history already contains the product, the amount is added to the existing value.
        //Otherwise, a new key-value pair is added to the purchase history with the product as the key
        //and the specified amount as the value.
        if (this.purchaseHistory.containsKey(p)) {
            this.purchaseHistory.put(p, purchaseHistory.get(p) + amount);
        } else {
            this.purchaseHistory.put(p, amount);
        }
    }

    public void printPurchaseHistory(){
        //Prints the customer purchase history
        for(Product p : purchaseHistory.keySet()){
            System.out.println(purchaseHistory.get(p) + "x " + p);
        }
    }

    //String representation of the Customer object
    public String toString() {
        return this.getName() + " who has spent $"+this.moneySpent;
    }

    //This method compares two customers based on the amount of money spent.
    public int compareTo(Customer other) {
        //If the current customer has spent more money than the other customer, it returns -1
        if (this.getMoneySpent() > other.getMoneySpent()) {
            return -1;
        //If the current customer has spent less money than the other customer, it returns 1
        } else if (this.getMoneySpent() < other.getMoneySpent()) {
            return 1;
        //If both customers have spent the same amount of money, it returns 0
        } else {
            return 0;
        }
    }

    //get and set methods

    public String getName() {
        return name;
    }
    public double getMoneySpent() {
        return moneySpent;
    }

    public void setMoneySpent(double moneySpent) {
        this.moneySpent = moneySpent;
    }

}
