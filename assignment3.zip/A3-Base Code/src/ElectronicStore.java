//Class representing an electronic store
//Has an array of products that represent the items the store can sell
import java.io.*;
import java.util.*;

import static java.lang.System.out;


public class ElectronicStore implements Serializable{
  public final int MAX_PRODUCTS = 10; //Maximum number of products the store can have
  //private int curProducts;
  private String name;
  private List<Product> stock; //Array to hold all products
  private double revenue;
  private List<Customer> customerList; // List of customers

  public ElectronicStore(String initName) {
    this.customerList = new ArrayList<Customer>();
    revenue = 0.0;
    name = initName;
    this.stock = new ArrayList<Product>();
  }

  //Create a boolean registerCustomer(Customer) method that will add the given Customer
  //object to the ElectronicStore. It should not be possible to add two customers with the
  //same name (i.e., the customer names within a store are unique). This method should
  //return true if the Customer was added successfully and false otherwise.
  public boolean registerCustomer(Customer c) {

    //loops through the List of customers to if the customer is added already,if so it will return false.
    //If the customer is new it will bw added to the List.
    for (Customer customer : customerList) {
      if (c.getName().equals(customer.getName())) {
        return false;
      }
    }
    customerList.add(c);
    return true;
  }

  public String getName() {
    return name;
  }

  // Goes through the Stock, to check if the newProduct already added to the stock to avoid duplicates
  public boolean addProduct(Product newProduct) {
    for (Product product : stock) {
      if (product.toString().equals(newProduct.toString())) {
        return false;
      }
    }
    stock.add(newProduct);
    return true;

  }
  public List<Product> searchProducts(String x) {
    List<Product> search1 = new ArrayList<Product>();
    //Goes through the stock List to check the String in the argument
    for (Product product : stock) {
      // Check if the product's String contains the search string and is case insensitive
      if (product.toString().toLowerCase().contains(x.toLowerCase())) {
        search1.add(product);
      }
    }

    return search1;
  }

  public List<Product> searchProducts(String x, double minPrice, double maxPrice) {
    List<Product> search = new ArrayList<Product>();
    //calls the searchProducts method to get a list of products that match the given string.
    List<Product> SearchWithMatchedString = searchProducts(x);
    //If both minimum price and maximum price are less than 0, it the full list of matched products is returned.
    if (minPrice < 0 && maxPrice < 0) {
      search = SearchWithMatchedString ;
    }else {
      //it goes through the matched products and adds only the ones whose prices fall within the
      //given price range to the new list which is returned.
      for (Product product : SearchWithMatchedString ) {
        if ((product.getPrice() <= maxPrice && product.getPrice() >= minPrice) ||
                (maxPrice < minPrice && product.getPrice() >= minPrice)) {
          search.add(product);
        }
      }
    }
    return search;
  }

  public boolean addStock(Product p, int amount) {
    // Search for a product in the stock that matches p 's String
    for (Product product : stock) {
      if (product.toString().equals(p.toString())) {
        // If a matching product is found, increase its stock quantity and returns true otherwise false is returned
        p.setStockQuantity(p.getStockQuantity() + amount);
        return true;
      }
    }
    return false;
  }

  public boolean sellProduct(Product p, Customer c, int amount) {
    // Checks if the store contains the product and has enough stock, and that the given customer exists in the customer list
    if (stock.contains(p) & p.getStockQuantity() >= amount & customerList.contains(c)) {
      // If so, the product is sold to the customer, Updates customer purchases ,store's revenue,
      // and the product's stock and sold quantity
      c.purchaseMade(p, amount);
      revenue+=p.getPrice() * amount;
      c.setMoneySpent(c.getMoneySpent() + p.getPrice() * amount);
      p.sellUnits(amount);
      //if successfull, true is returned otherwise false is returned
      return true;
    }
    return false;
  }

  public List<Customer> getTopXCustomers(int x) {
    Collections.sort(customerList);
    //Sorts customers in decreasing order based on moneySpent
    List<Customer> top = new ArrayList<Customer>();
     // If X is less than or equal to zero, return an empty list
    if (x <= 0) {
      return top;
    // If X is greater than or equal to the size of the customer list, the entire customer list is returned.
    } else if (x >= customerList.size()) {
      return customerList;
    } else {
      // Otherwise, return the top X customers
      int loop = 0;
      List<Customer> copy = new ArrayList<Customer>(customerList);
      while (x > loop) {
        top.add(copy.remove(0));
        loop++;
      }
      return top;
    }
  }


  public boolean saveToFile(String fileName) {
    try {
      // Create an ObjectOutputStream to write the Shop object to a file
      ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fileName));
      // Write the Shop object to the file
      out.writeObject(this);
      out.close();
      // Returns true if successful
      return true;
    } catch (IOException e) {
      // Prints if the IOException is thrown
      System.out.println("input/output operation fails");
      //return false if not successful
      return false;
    }
  }

  public static ElectronicStore loadFromFile(String filename) {
    try {
      // Create an ObjectInputStream to read a serialized ElectronicStore object from the given file
      ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename));
      // Read the ElectronicStore object from the file and typecast it to an ElectronicStore instance
      ElectronicStore x = (ElectronicStore) in.readObject();
      //returns the objects
      return x;
    } catch (FileNotFoundException e){
      //Prints if the file is not found
      System.out.println("File not found");
    }catch (IOException e) {
      // Prints if an IO exception occurs
      System.out.println("input/output operation fails");
    } catch (ClassNotFoundException e) {
      // Print if the class is not found
      System.out.println("Class not found");
    }
    return null;
  }

  //Get method
  public List<Customer> getCustomers() {
    return customerList;
  }
}